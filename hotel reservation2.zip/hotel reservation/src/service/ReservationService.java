package service;

import model.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.*;

public class ReservationService {
    private final Map<String, IRoom> roomLookup;
    private final Map<Customer, Collection<Reservation>> reservationsByCustomer;
    private final Map<Date, Collection<IRoom>> reservedRoomByDate;
    private final static ReservationService reference = new ReservationService();

    public static ReservationService getInstance() {
        return reference;
    }

    private ReservationService() {
        this.roomLookup = new HashMap<String, IRoom>();
        this.reservationsByCustomer = new HashMap<Customer, Collection<Reservation>>();
        this.reservedRoomByDate = new HashMap<Date, Collection<IRoom>>();  //TODO Change to treemap with comparator to date - or no order needed
    }

    public final void addRoom(IRoom room) {
        if (roomLookup.containsValue(room))
            throw new IllegalArgumentException("Cannot add room because room number already exists on reservation system");
        roomLookup.put(room.getRoomNumber(), room);
    }

    public final IRoom getARoom(String roomID) {
        // returns null if room does not exist.
        return roomLookup.get(roomID);
    }

    /*
    When a customer is created in  CustomerService, this default (package private) method is called so that the
    reservation system data structure is set up to store reservations for that customer.
    */
    void initialiseCustomer(Customer customer) {
        reservationsByCustomer.putIfAbsent(customer, new ArrayList<Reservation>());
    }


    public final Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {

        // Create reservation and store in map
        Reservation createdReservation = new Reservation(customer, room, checkInDate, checkOutDate);

        if(reservationsByCustomer.get(customer).contains(createdReservation))
            throw new RuntimeException("The reservation already exists");

        reservationsByCustomer.get(customer).add(createdReservation);

        // Store reservation for fast look up of IRoom availability
        // For reservationsByDate, add IRoom for each inDate from checkInDate to checkOutDate
        // If date does not exist in reservationsByDate, then new map entry and collection is created.
        Date inDate = checkInDate;

        Calendar ca = Calendar.getInstance();
        ca.setTime(inDate);

        while (!inDate.after(checkOutDate)) {
            reservedRoomByDate.putIfAbsent(inDate, new HashSet<IRoom>());
            reservedRoomByDate.get(inDate).add(room);
            ca.add(Calendar.DATE, 1);
            inDate = ca.getTime();
        }
        return createdReservation;
    }


    public final Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {

        // Start with set of potentialRooms which is  all rooms
        // For each Date in the reservation period eliminate rooms with a booking
        Collection<IRoom> foundRooms = new HashSet<IRoom>(roomLookup.values());

        // Return all rooms if null arguments for dates
        // (this is a bit hacky but follows the class specification)
        if (checkInDate == null && checkOutDate == null) return foundRooms;

        Date inDate = checkInDate;
        Calendar cal = Calendar.getInstance();
        cal.setTime(inDate);

        while (!inDate.after(checkOutDate)) {
            if (reservedRoomByDate.get(inDate) != null) {
                foundRooms.removeAll(reservedRoomByDate.get(inDate));
            }
            cal.add(Calendar.DATE, 1);
            inDate = cal.getTime();
        }
        return foundRooms;
    }

    public final Collection<Reservation> getCustomerReservation(Customer customer) {
        return reservationsByCustomer.getOrDefault(customer, new ArrayList<Reservation>());
    }

    // The specifications had no return type when one might expect a return object to the api layer
    // This method is likely used to create a report on a device such as a print.
    // For now, it is printed to screen.
    public final void printAllReservation() {
        for (Customer cus : reservationsByCustomer.keySet()) {
            for (Reservation res : reservationsByCustomer.get(cus)) {
                System.out.println(res);
                System.out.println("************************************************");
            }
        }

    }


}