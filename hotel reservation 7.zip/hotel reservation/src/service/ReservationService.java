package service;

import model.*;

import java.util.*;


public class ReservationService {


    // Rooms are added to a Set (implemented as hashset).  This ensures identical rooms are not stored.
    private final Set<IRoom> roomLookup;

    // Each Date is mapped to a Set<IRoom> for tracking reservations and used when looking up available rooms .
    // This data structure (implemented as hashset) ensures that rooms cannot be booked for the same time (date).
    private final Map<Date, Set<IRoom>> reservedRoomByDate;

    private final Map<Customer, Set<Reservation>> reservationsByCustomer;

    private final static ReservationService reference = new ReservationService();

    public static ReservationService getInstance() {
        return reference;
    }

    // constructor is a private method as this is Singleton pattern.
    private ReservationService() {
        this.roomLookup = new HashSet<IRoom>();
        this.reservationsByCustomer = new HashMap<Customer, Set<Reservation>>();
        this.reservedRoomByDate = new HashMap<Date, Set<IRoom>>();
    }

    public final void addRoom(IRoom room) {
        if (roomLookup.contains(room))
            throw new IllegalArgumentException("Cannot add room because room number already exists on reservation system");
        else  roomLookup.add(room);
    }

    public final IRoom getARoom(String roomID) {
        // returns null if room does not exist.
        for(IRoom room : roomLookup) {
            if (room.getRoomNumber().equals(roomID)) return room;
        }
        return null;
    }

    /*
    When a customer is created in  CustomerService.
    This  default (package private) method is called so that the reservation system has a data structure
    set up to store reservations for that customer.
    */
    void initialiseCustomer(Customer customer) {
        reservationsByCustomer.putIfAbsent(customer, new HashSet<Reservation>());
    }


    public final Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {

        // Create reservation and store in map
        Reservation createdReservation = new Reservation(customer, room, checkInDate, checkOutDate);

        if(reservationsByCustomer.get(customer).contains(createdReservation))
            throw new RuntimeException("The reservation already exists");
        else reservationsByCustomer.get(customer).add(createdReservation);

        // Store reservation for fast look up of IRoom availability
        // For reservationsByDate, add IRoom for each inDate from checkInDate to checkOutDate
        // If date does not exist in reservationsByDate, then new map entry and collection is created.
        Date inDate = checkInDate;
        Calendar ca = Calendar.getInstance();
        ca.setTime(inDate);

        while (!inDate.after(checkOutDate)) {
            reservedRoomByDate.putIfAbsent(inDate, new HashSet<IRoom>());

            // This is a validation check to ensure integrity but would not be encountered in current UI as checks
            // exist when searching for a room.
            if(reservedRoomByDate.get(inDate).contains(room)){
                throw new RuntimeException("The reservation is not allowed as the room is not available for the whole date range" +
                        "" + createdReservation +
                        "" +
                        "");
            }

            reservedRoomByDate.get(inDate).add(room);
            ca.add(Calendar.DATE, 1);
            inDate = ca.getTime();
        }
        return createdReservation;
    }



    public final Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {

        // Start with set of potentialRooms which is  all rooms
        // For each Date in the reservation period eliminate rooms with a booking
        Collection<IRoom> foundRooms = new HashSet<IRoom>(roomLookup);

        // Return all rooms if null arguments for dates
        // (this is a bit hacky but follows the class specification)
        if (checkInDate == null && checkOutDate == null) return foundRooms;

        Date inDate = checkInDate;
        Calendar cal = Calendar.getInstance();
        cal.setTime(inDate);

        while (!inDate.after(checkOutDate)) {
            if (reservedRoomByDate.get(inDate) != null) {
                foundRooms.removeAll(reservedRoomByDate.get(inDate));
            }
            cal.add(Calendar.DATE, 1);
            inDate = cal.getTime();
        }
        return foundRooms;
    }

    public final Collection<Reservation> getCustomerReservation(Customer customer) {
        return reservationsByCustomer.getOrDefault(customer, new HashSet<Reservation>());
    }

    // The specifications had no return type when one might expect to return an object to the api layer
    // Perhaps, this method could be used to create a report on a device such as a printer.
    // For now, the reservations are simply printed to screen.
    public final void printAllReservation() {
        for (Customer cus : reservationsByCustomer.keySet()) {
            for (Reservation res : reservationsByCustomer.get(cus)) {
                System.out.println(res);
                System.out.println("************************************************");
            }
        }

    }


}